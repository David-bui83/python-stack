from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    user = {'first_name': request.form['first_name'],
    'last_name': request.form['last_name'],
    'student_id': request.form['student_id']
    }

    fruits = { 
        'strawberry': request.form['strawberry'],
        'raspberry': request.form['raspberry'],
        'apple': request.form['apple'],
        'blackberry': request.form['blackberry']
    }

    total = 0
    for num in fruits.values():
        total += int(num)

    print(request.form)
    
    return render_template("checkout.html", fruits=fruits, user=user, total=total)

@app.route('/fruits')         
def fruits():

    fruits = {
        'strawberry': '/static/img/strawberry.png',
        'raspberry': '/static/img/raspberry.png',
        'apple': '/static/img/apple.png',
        'blackberry': '/static/img/blackberry.png'
    }

    return render_template("fruits.html", fruits=fruits)

if __name__=="__main__":   
    app.run(debug=True)    