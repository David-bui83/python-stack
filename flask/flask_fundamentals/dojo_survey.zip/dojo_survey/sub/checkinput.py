
def checkForEmpty(val=''):
  if (val):
    value  = val
    return value
  else:
    value = ''
    return value