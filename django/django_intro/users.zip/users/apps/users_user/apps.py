from django.apps import AppConfig


class UsersUserConfig(AppConfig):
    name = 'users_user'
