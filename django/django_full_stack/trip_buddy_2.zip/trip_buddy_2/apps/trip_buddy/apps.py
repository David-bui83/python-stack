from django.apps import AppConfig


class TripBuddyConfig(AppConfig):
    name = 'trip_buddy'
